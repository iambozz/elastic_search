package io.elasticsearch.service;

import java.util.*;

import io.elasticsearch.model.Product;
import io.elasticsearch.repository.ProductRepository;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.common.settings.Settings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.elasticsearch.model.Customer;
import io.elasticsearch.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	ProductRepository productRepository;

	private RestHighLevelClient restHighLevelClient;

	public Iterable<Customer> findAll() {
		return customerRepository.findAll();
	}

	public List<Customer> findByFirstName(String firstName) {
		return customerRepository.findByFirstName(firstName);
	}

	public List<Customer> findByLastName(String lastName) {
		return customerRepository.findByLastName(lastName);
	}

	public Customer save(Customer customer) {
		return customerRepository.save(customer);
	}

	public Iterable<Customer> saveAll(List<Customer> customers) {
		return customerRepository.saveAll(customers);
	}

	public Product createProduct(Product product) {
		return productRepository.save(product);
	}
	public Optional<Product> getProduct(String id) {
		return productRepository.findById(id);
	}

	public boolean createProductIndex() {
		CreateIndexRequest createIndexRequest = new CreateIndexRequest("product");
		createIndexRequest.settings(Settings.builder()
				.put("number_of_shards", 1)
				.put("number_of_replicas", 0)
				.build());
		Map<String, Map<String, String>> mappings = new HashMap<>();

		mappings.put("name", Collections.singletonMap("type", "text"));
		mappings.put("category", Collections.singletonMap("type", "keyword"));
		mappings.put("price", Collections.singletonMap("type", "long"));
		createIndexRequest.mapping(Collections.singletonMap("properties", mappings));
		try {
			CreateIndexResponse createIndexResponse = restHighLevelClient.indices()
					.create(createIndexRequest, RequestOptions.DEFAULT);
			return createIndexResponse.isAcknowledged();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public Iterable<Product> insertBulk(List<Product> products) {
		return productRepository.saveAll(products);
	}

}
