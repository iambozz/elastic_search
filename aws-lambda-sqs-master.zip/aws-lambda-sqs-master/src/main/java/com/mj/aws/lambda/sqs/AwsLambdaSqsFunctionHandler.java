package com.mj.aws.lambda.sqs;

import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

import com.amazonaws.services.lambda.runtime.events.SQSEvent;

public class AwsLambdaSqsFunctionHandler extends SpringBootRequestHandler<SQSEvent, String> {
}
