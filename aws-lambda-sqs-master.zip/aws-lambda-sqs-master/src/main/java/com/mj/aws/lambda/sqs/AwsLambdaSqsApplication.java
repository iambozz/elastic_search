package com.mj.aws.lambda.sqs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsLambdaSqsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsLambdaSqsApplication.class, args);
	}
}
